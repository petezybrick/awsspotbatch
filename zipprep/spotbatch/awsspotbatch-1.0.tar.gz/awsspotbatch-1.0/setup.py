'''
Created on Mar 12, 2015

@author: pete.zybrick
'''
from distutils.core import setup

setup(name='awsspotbatch',
      version='1.0',
      description='IPC AWS Spot Batch Scripts',
      author='Pete Zybrick',
      author_email='pete.zybrick@ipc-global.com',
      url='https:// TODO: SVN link to branch',
      packages=['awsspotbatch'],
      package_dir = {'': 'src'},
     )