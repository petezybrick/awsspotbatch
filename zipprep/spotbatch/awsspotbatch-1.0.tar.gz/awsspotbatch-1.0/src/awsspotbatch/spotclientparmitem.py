'''
Created on Mar 12, 2015

@author: pete.zybrick
'''
import json


class SpotClientParmItem(object):
    '''
    classdocs
    '''


    def __init__(self, pathInParmFile ):
        with open( pathInParmFile ) as json_data:
            parms = json.load(json_data)
            json_data.close()

        self.region_name = parms['region_name']
        self.profile_name = parms[ 'profile_name']
        if self.profile_name == 'None': self.profile_name = None
        
        self.spot_master_uuid = parms['spot_master_uuid']
        self.queue_name = parms['queue_name']
        self.spot_instance_request_id = parms['spot_instance_request_id']
        self.script_name_args = parms['script_name_args']

        
    def to_json(self):
        json_dict = { 
                     "spot_master_uuid":self.spot_master_uuid,
                     "spot_instance_request_id":self.spot_instance_request_id,
                     "ts_status":self.ts_status,
                     "reason_code":self.reason_code,
                     "reason_message_dict":self.reason_message_dict,
                     "termination_time_utc":self.termination_time_utc,
                     "termination_time_exception":self.termination_time_exception,
                     }
        return json.dumps(json_dict)


    def write_to_file(self, pathOutParmFile ):
        with open(pathOutParmFile, "w") as text_file:
            text_file.write( self.to_json )
        