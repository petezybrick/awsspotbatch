Version = '1.0'

def trimStdOutErrSqsPayload( std_out, std_err ):
    
    # SQS payload max length is 256K, so trim down to 250K for the out/err lengths if necessary
    max_payload_len = 250*1024
    if len(std_out) + len(std_err) > max_payload_len:
        if len(std_err) == 0: std_out = std_out[:max_payload_len] + '...'
        elif len(std_out) == 0: std_err = std_err[:max_payload_len] + '...'
        else:
            tot_len = len(std_out) + len(std_err)
            std_out_len_adj = int( ( len(std_out) / float(tot_len) ) * tot_len )
            std_err_len_adj = int( ( len(std_err) / float(tot_len) ) * tot_len )
            std_out = std_out[:std_out_len_adj] + '...'
            std_err = std_err[:std_err_len_adj] + '...'
    return std_out, std_err
