'''
Created on Mar 16, 2015

@author: pete.zybrick
'''
import sys
import traceback
import subprocess
import awsspotbatch.spotinstance
from ipcaws.sqs.messagedurable import SqsMessageDurable
from spotclientparmitem import SpotClientParmItem


def main():     
    if( len(sys.argv) < 3 ):
        print 'Invalid format, execution cancelled'
        print 'Correct format: python awsspotbatch.spotclientlaunch <parmFile.json> <consoleConfigFile.conf>'
        sys.exit(8)
    
    import logging.config
    logging.config.fileConfig( sys.argv[2], disable_existing_loggers=False)
    logger = logging.getLogger(__name__)
    
    try:
        spot_client_parm_item = SpotClientParmItem( sys.argv[1] )    
        logger.info( 'Starting, region_name=' + spot_client_parm_item.region_name + ', profile_name=' + str(spot_client_parm_item.profile_name) )
        spot_instance_status_thread = awsspotbatch.spotinstance.SpotInstanceStatusThread( 
                                                                                         spot_client_parm_item.queue_name, 
                                                                                         spot_client_parm_item.region_name, 
                                                                                         profile_name=spot_client_parm_item.profile_name,
                                                                                         spot_master_uuid=spot_client_parm_item.spot_master_uuid, 
                                                                                         spot_instance_request_id=spot_client_parm_item.spot_instance_request_id)
        spot_instance_status_thread.start()    
        child_process = subprocess.Popen( spot_client_parm_item.script_name_args, stdout=subprocess.PIPE, stderr=subprocess.PIPE )
        std_out, std_err = child_process.communicate( )
        returncode = child_process.returncode    
        std_out, std_err = awsspotbatch.trimStdOutErrSqsPayload( std_out, std_err )
        sqs_message_send_durable = SqsMessageDurable( spot_client_parm_item.queue_name, 
                                                                                        spot_client_parm_item.region_name, 
                                                                                        profile_name=spot_client_parm_item.profile_name )
        reason_message_dict = { 'returncode':str(returncode), 'std_out':std_out, 'std_err':std_err }
        sqs_message_send_durable.send_message( awsspotbatch.spotinstance.SpotInstanceStatusMessage( 
                                                                                                     spot_master_uuid=spot_client_parm_item.spot_master_uuid, 
                                                                                                     spot_instance_request_id=spot_client_parm_item.spot_instance_request_id,
                                                                                                     reason_code='batch_process_complete', 
                                                                                                     reason_message_dict=reason_message_dict ).to_json() )        
        logger.info( 'Completed Successfully, child_process returncode=' + str(returncode) )

    except StandardError as e:
        logger.error( e )
        logger.error( traceback.format_exc() )
        sys.exit(8)

      
if __name__ == "__main__":
    main()