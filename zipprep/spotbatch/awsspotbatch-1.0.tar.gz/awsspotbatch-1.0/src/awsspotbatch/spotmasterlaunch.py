'''
Created on Feb 28, 2015

@author: pete.zybrick
'''
import uuid
import sys
import os
import datetime
import time
import boto.ec2
import boto.vpc
import ipcaws.exception
from ipcaws.ec2.spotprice import SpotRegionItem, find_spot_cheapest_prices
from ipcaws.iam.connection.IpcIAMConnection import create_unique_role_instance_profile_sync, delete_role_instance_profile_sync
from ipcaws.ec2.connection.IpcEC2Connection import poll_instances_running, poll_instances_terminated

import logging.config
logging.config.fileConfig('../../config/consoleonly.conf', disable_existing_loggers=False)
logger = logging.getLogger(__name__)

profile_name = 'ipc-training'
regions = ['us-east-1']
image_id = 'ami-146e2a7c'       # Region dependent, will require map or some other lookup
spot_instance_count = 2

# These VPC's must already exist
# TODO: create a separate script/CF template to create Spot VPC per region, with one Subnet per AZ in the region
spot_vpcs_by_region = { 'us-east-1' : 'vpc-f3f49896' }
# TODO: find this programmatically by VPC with naming or from DynamoDB table
map_subnet_ids_by_zone = { 
    'us-east-1b':'subnet-32af0e19', 
    'us-east-1c':'subnet-1acd566d',
    'us-east-1d':'subnet-cdae1694',
    'us-east-1e':'subnet-45d69b7f',
    }
policy_path = '/home/pete.zybrick/temp/spot_policies/spot_policy_deny_all.txt'
user_data = 'Watson, come here. I need you'     # TODO: read from external user-specified file
valid_until_minutes = 15
poll_interval_secs = 10
dry_run = False
kp_name_prefix = 'kp_spot_'
key_path = '/home/pete.zybrick/.pzkeys/'
sg_name_prefix = 'sg_spot_'
role_name_prefix='role_spot_' 
instance_profile_name_prefix='ip_spot_'
policy_name_prefix='Policy-Spot-'

instance_ids = []
role_instance_profile_item = None
# TODO: this could be passed in arg to restart/continue/terminate a previous run
uuid = uuid.uuid1()

logger.info( 'Starting... ' + uuid )
# TODO: insert row into DynamoDB to track this run
# TODO: wrap in master try/catch, delete resources in master finally

spot_cheapest_items = find_spot_cheapest_prices(
    instance_type='m3.large',
    region_filter=regions,
    profile_name=profile_name,
    verbose=True
    );
if len(spot_cheapest_items) == 0:
    logger.error( 'ERROR: Could not find a spot price' )
    sys.exit(8)
    
# Role is per account, not per region.  Create role and instance profile, using policy from user-specified external file
with open( policy_path, 'r' ) as policy_file:
    policy = policy_file.read()
    policy_file.close()
iam_conn = boto.connect_iam(profile_name=profile_name)
role_instance_profile_item = create_unique_role_instance_profile_sync( iam_conn, policy,
                                                           role_name_prefix=role_name_prefix, 
                                                           instance_profile_name_prefix=instance_profile_name_prefix,
                                                           policy_name_prefix=policy_name_prefix )
    
# If multiple attempts will be made, only create one vpc connection, ec2 connection, key pair and security group per region
map_spot_region_items_by_region_name = {}
    
for spot_cheapest_item in spot_cheapest_items:
    logger.info( 'Attempting to acquire spot instances in: ' + spot_cheapest_item.zone.name + ' at price: ' + str( spot_cheapest_item.price) )

    # TODO: need map of max prices per instance type, if cheapest> then exit - or maybe sleep for awhile?
    
    subnet_id = map_subnet_ids_by_zone[ spot_cheapest_item.zone.name ]
    
    if spot_cheapest_item.region.name not in map_spot_region_items_by_region_name:
        spot_region_item = SpotRegionItem( spot_cheapest_item.region.name, key_path=key_path, vpc_id=spot_vpcs_by_region[spot_cheapest_item.region.name] ) 
        map_spot_region_items_by_region_name[ spot_cheapest_item.region.name ] = spot_region_item
    else: spot_region_item = map_spot_region_items_by_region_name[ spot_cheapest_item.region.name ]
    
    valid_until = datetime.datetime.utcnow() + datetime.timedelta( minutes=valid_until_minutes )
    valid_until_iso = valid_until.isoformat()
    
    spot_instance_requests = spot_region_item.ec2_conn.request_spot_instances(
        spot_cheapest_item.price, image_id=image_id, count=spot_instance_count, 
        type='one-time', 
        dry_run=dry_run,
        valid_until=valid_until_iso, 
        user_data=user_data, 
        instance_type=spot_cheapest_item.instance_type,
        placement=spot_cheapest_item.zone.name, 
        instance_profile_name=role_instance_profile_item.instance_profile_name,
        key_name=spot_region_item.key_name,
        security_group_ids=spot_region_item.security_group_ids,
        subnet_id=subnet_id,
        availability_zone_group='single',
        )
                                         
    for spot_instance_request in spot_instance_requests: logger.info('Spot Request: ' + spot_instance_request.id )
    
    logger.info( 'Begin Polling Spot Requests' )   
    try:
        instance_ids = spot_region_item.ec2_conn.poll_spot_request( spot_region_item.ec2_conn, spot_instance_requests, poll_interval_secs, valid_until_minutes, verbose=True )
        break;  # successfully acquired the spot instances
    except ipcaws.exception.SpotConstraintError as e:
        # cancel the current spot requests
        for spot_instance_request in spot_instance_requests: spot_instance_request_ids = [ spot_instance_request.id ]
        spot_region_item.ec2_conn.cancel_spot_instance_requests( spot_instance_request_ids )
        logger.error( e )
        continue    # check the next spot_cheapest_item
    except ipcaws.exception.SpotPollTimeoutError as e:
        logger.error( e )
        sys.exit(8)
        
if( len(instance_ids) == 0 ):
    logger.error( 'Error: could not acquire instances' )
    sys.exit(8)

logger.info( 'Instance Ids: ' + str(instance_ids) )
logger.info( 'Poll Instances for Running' )
poll_instances_running_minutes = 15
try:
    poll_instances_running( spot_region_item.ec2_conn, instance_ids, poll_interval_secs, poll_instances_running_minutes, verbose=True)
except ipcaws.exception.InstancePollTimeoutError as e:
    sys.exit(8)

logger.info( 'Instances are running, sleep for a minute' )
time.sleep(60)

#TODO: run remote batch programs.  These may run for a long time.
#IDEA: code above launches and runs.  Code below is separate and run from a monitor that polls DynamoDB table for batch job completion
 
logger.info( 'Cleaning Up' )
logger.info( 'Terminate the instances' )
poll_instances_terminated_minutes = 15
ec2_conn = boto.ec2.connect_to_region( spot_cheapest_item.region.name, profile_name=profile_name )
ec2_conn.terminate_instances( instance_ids )
try:
    poll_instances_terminated( ec2_conn, instance_ids, poll_interval_secs, poll_instances_terminated_minutes, verbose=True)
except ipcaws.exception.InstancePollTimeoutError as e:
    logger.error( e )

# TODO: wrap each in try/catch, just log any errors and continue
# Question: what if the connections time out?  if a job ran for a few hours, maybe these connections could timeout, should the be re-verified/reconnected?
logger.info( 'Deleting Keys, KeyPairs and SecurityGroups' )
delete_role_instance_profile_sync( iam_conn, role_instance_profile_item );
for spot_region_item in map_spot_region_items_by_region_name.values():
    os.remove( key_path + spot_region_item.key_name + '.pem' )
    ec2_conn = boto.ec2.connect_to_region( spot_region_item.region.name, profile_name=profile_name )
    ec2_conn.delete_key_pair( spot_region_item.key_name )
    vpc_conn = boto.vpc.connect_to_region( spot_region_item.region.name, profile_name=profile_name )
    vpc_conn.delete_security_group( group_id=spot_region_item.security_group.id )
    
    
    
