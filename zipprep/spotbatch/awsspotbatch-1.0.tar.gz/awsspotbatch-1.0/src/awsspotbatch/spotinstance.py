'''
Created on Mar 17, 2015

@author: pete.zybrick
'''
import json
import threading
import datetime
import time
import subprocess
from ipcaws.sqs.messagedurable import SqsMessageDurable


cmdMetadataTerminateTime = 'if curl -s http://169.254.169.254/latest/meta-data/spot/termination-time | grep -q .*T.*Z; then echo terminated; fi'
heartbeat_interval_seconds = 10
check_termination_time_interval_seconds = 5
   
import logging
logger = logging.getLogger(__name__)


class SpotInstanceStatusMessage():
    
    def __init__(self, spot_master_uuid=None, spot_instance_request_id=None, ts_status=None, reason_code='heartbeat', reason_message_dict=None, termination_time_utc=None, termination_time_exception=None, raw_json=None):
        if raw_json == None:
            if spot_master_uuid == None: raise ValueError('spot_master_uuid is required')
            if spot_instance_request_id == None: raise ValueError('spot_instance_request_id is required')
            self.spot_master_uuid = spot_master_uuid
            self.spot_instance_request_id = spot_instance_request_id
            if ts_status == None: self.ts_status = datetime.datetime.utcnow().isoformat()
            else: self.ts_status = ts_status
            self.reason_code = reason_code
            self.reason_message_dict = reason_message_dict
            self.termination_time_utc = termination_time_utc
            self.termination_time_exception = termination_time_exception
        else:
            json_dict = json.loads( raw_json )
            self.spot_master_uuid = json_dict["spot_master_uuid"]
            self.spot_instance_request_id = json_dict["spot_instance_request_id"]
            self.ts_status = json_dict["ts_status"]
            self.reason_code = json_dict["reason_code"]
            self.reason_message_dict = json_dict["reason_message_dict"]
            self.termination_time_utc = json_dict["termination_time_utc"]
            self.termination_time_exception = json_dict["termination_time_exception"]

        
    def to_json(self):
        json_dict = { 
                     "spot_master_uuid":self.spot_master_uuid,
                     "spot_instance_request_id":self.spot_instance_request_id,
                     "ts_status":self.ts_status,
                     "reason_code":self.reason_code,
                     "reason_message_dict":self.reason_message_dict,
                     "termination_time_utc":self.termination_time_utc,
                     "termination_time_exception":self.termination_time_exception,
                     }
        
        return json.dumps(json_dict)
        

class SpotInstanceTerminationTimeThread(threading.Thread):
    
    def __init__(self, spot_instance_status_thread ):
        threading.Thread.__init__(self)
        self.spot_instance_status_thread = spot_instance_status_thread
        self.test_cnt = 0
        self.is_shutdown = False
        
        
    def shutdown(self):
        self.is_shutdown = True
                
    
    def run(self):
        num_contiguous_errors = 0
        max_contiguous_errors = 10  # if popen fails 10 times in a row, then save last exception/error and exit
        while True:
            if self.is_shutdown: break
            # TEST TEST TEST
            self.test_cnt += 1
            if self.test_cnt == 5:
                self.spot_instance_status_thread.termination_time_utc = '2015-01-05T18:02:00Z'
                break;
            
            try:
                # http://docs.aws.amazon.com/AWSEC2/latest/UserGuide/spot-intsqs_message_sender_durableerruptions.html
                process = subprocess.Popen( cmdMetadataTerminateTime, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE )
                std_out, std_err = process.communicate()
                returncode = process.returncode
                if len(std_err) > 0:
                    num_contiguous_errors += 1;
                    if num_contiguous_errors < max_contiguous_errors: continue
                    self.spot_instance_status_thread.termination_time_exception = 'SpotTerminatedTimeCheckDataError, std_err=' + std_err
                    break
                elif returncode != 0:
                    num_contiguous_errors += 1;
                    if num_contiguous_errors < max_contiguous_errors: continue
                    self.spot_instance_status_thread.termination_time_exception = 'SpotTerminatedTimeCheckReturnCodeError, returncode=' + returncode
                    break
                elif len(std_out) == 20: 
                    self.spot_instance_status_thread.termination_time_utc = std_out
                    break;
                elif len(std_out) > 0:
                    num_contiguous_errors += 1;
                    if num_contiguous_errors < max_contiguous_errors: continue
                    self.spot_instance_status_thread.termination_time_exception = 'SpotTerminatedTimeCheckDataError, std_our=' + std_out
                else:
                    num_contiguous_errors = 0
                time.sleep( check_termination_time_interval_seconds )
                
            except OSError as ose:
                self.spot_instance_status_thread.termination_time_exception = str(ose)
                break;
            except ValueError as ve:
                self.spot_instance_status_thread.termination_time_exception = str(ve)
                break;
            except StandardError as se:
                self.spot_instance_status_thread.termination_time_exception = str(se)
                break;            
            

class SpotInstanceStatusThread(threading.Thread):
    
    def __init__(self, queue_name, region_name, profile_name=None, spot_master_uuid=None, spot_instance_request_id=None,  ):
        threading.Thread.__init__(self)
        if spot_master_uuid == None: raise ValueError('spot_master_uuid is required')
        if spot_instance_request_id == None: raise ValueError('spot_instance_request_id is required')
        self.sqs_message_sender_durable = SqsMessageDurable( queue_name, region_name, profile_name=profile_name )
        self.spot_master_uuid = spot_master_uuid
        self.spot_instance_request_id = spot_instance_request_id
        self.spot_instance_termination_time_thread = SpotInstanceTerminationTimeThread( self )
        self.spot_instance_termination_time_thread.start()
        
        self.termination_time_utc = ''
        self.termination_time_exception = None

        self.test_cnt = 0
    
    
    def run(self):
        self.sqs_message_sender_durable.send_message( SpotInstanceStatusMessage( spot_master_uuid=self.spot_master_uuid, spot_instance_request_id=self.spot_instance_request_id,reason_code='heartbeat_daemon_started' ).to_json() )
        wakeup_at_heartbeat = time.time() + heartbeat_interval_seconds
        while True: 
            time.sleep( check_termination_time_interval_seconds )
            if time.time() > wakeup_at_heartbeat:
                wakeup_at_heartbeat = time.time() + heartbeat_interval_seconds
                self.sqs_message_sender_durable.send_message( SpotInstanceStatusMessage( spot_master_uuid=self.spot_master_uuid, spot_instance_request_id=self.spot_instance_request_id ).to_json() )

            if len( self.termination_time_utc ) > 0:
                # Instance is going to be terminated within 2 minutes
                self.sqs_message_sender_durable.send_message( SpotInstanceStatusMessage( spot_master_uuid=self.spot_master_uuid, spot_instance_request_id=self.spot_instance_request_id,
                                                              reason_code='pending_termination_detected', termination_time_utc=self.termination_time_utc ).to_json() )
                break
            elif self.termination_time_exception != None:
                # Instance is going to be terminated within 2 minutes
                self.sqs_message_sender_durable.send_message( SpotInstanceStatusMessage( spot_master_uuid=self.spot_master_uuid, spot_instance_request_id=self.spot_instance_request_id,
                                                              reason_code='pending_termination_exception', termination_time_exception=self.termination_time_exception ).to_json() )
                break
        self.spot_instance_termination_time_thread.shutdown()

