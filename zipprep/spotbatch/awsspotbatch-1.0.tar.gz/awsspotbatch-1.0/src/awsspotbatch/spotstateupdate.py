'''
Created on Mar 17, 2015

@author: pete.zybrick
'''
import sys
import traceback
from ipcaws.sqs.messagedurable import SqsMessageDurable


def main():
    
    if( len(sys.argv) < 3 ):
        print 'Invalid format, execution cancelled'
        print 'Correct format: python awsspotbatch.spotclientlaunch <parmFile.json> <consoleConfigFile.conf>'
        sys.exit(8)
    
    import logging.config
    logging.config.fileConfig( sys.argv[2], disable_existing_loggers=False)
    logger = logging.getLogger(__name__)
    
    try:
        # need to get these from DynamoDB
        queue_name = 'pzt1'
        region_name = 'us-east-1'
        profile_name = 'ipc-training'
        sqs_message_receive_durable = SqsMessageDurable(queue_name, region_name, profile_name=profile_name)
        
        while True:
            logger.info("before receive")              
            messages = sqs_message_receive_durable.receive_messages(number_messages=10)
            logger.info("after receive")              
            #if len(messages) == 0: break;
            for message in messages:
                print 'Insert DynamoDB: ' + str(message.get_body())
            sqs_message_receive_durable.delete_messages( messages )    
        
        logger.info( 'Completed Successfully' ) 

    except StandardError as e:
        logger.error( e )
        logger.error( traceback.format_exc() )
        sys.exit(8)

      
if __name__ == "__main__":
    main()