'''
Created on Mar 12, 2015

@author: pete.zybrick
'''
from distutils.core import setup

setup(name='ipcaws',
      version='1.1',
      description='IPC AWS Classes',
      author='Pete Zybrick',
      author_email='pete.zybrick@ipc-global.com',
      url='https:// TODO: SVN link to branch',
      packages=['ipcaws', 'ipcaws.ec2', 'ipcaws.iam', 'ipcaws.sqs', 'ipcaws.vpc'],
      package_dir = {'': 'src'},
     )