import ipcaws.vpc.connection
from boto.regioninfo import RegionInfo, get_regions


def regions(**kw_params):
    """
    Get all available regions for the EC2 service.
    You may pass any of the arguments accepted by the VPCConnection
    object's constructor as keyword arguments and they will be
    passed along to the VPCConnection object.

    :rtype: list
    :return: A list of :class:`boto.ec2.regioninfo.RegionInfo`
    """
    return get_regions('ec2', connection_cls=ipcaws.vpc.connection.IpcVPCConnection)


def connect_to_region(region_name, **kw_params):
    """
    Given a valid region name, return a
    :class:`ipcaws.vpc.connection.IpcVPCConnection`.
    Any additional parameters after the region_name are passed on to
    the connect method of the region object.

    :type: str
    :param region_name: The name of the region to connect to.

    :rtype: :class:`ipcaws.vpc.connection.IpcVPCConnection` or ``None``
    :return: A connection to the given region, or None if an invalid region
             name is given
    """
    for region in regions(**kw_params):
        if region.name == region_name:
            return region.connect(**kw_params)
    return None