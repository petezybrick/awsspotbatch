'''
Created on Mar 6, 2015

@author: pete.zybrick
'''
import time
import ipcaws.exception
import boto.vpc

import logging
logger = logging.getLogger(__name__)


class IpcVPCConnection(boto.vpc.VPCConnection):

    def __init__(self, **kw_params):
        super(IpcVPCConnection, self).__init__(**kw_params)
    
    
    def delete_security_group_sync( self, vpc_id, group_name=None, group_id=None, poll_interval_secs=5, poll_max_minutes=10 ):
        group_id, is_group_exists = self.is_security_group_exists( vpc_id, group_name=group_name, group_id=group_id)
        if not is_group_exists:
            if group_name != None: error_parm = group_name
            else: error_parm = group_id 
            raise ipcaws.exception.SecurityGroupDoesntExistError( error_parm, error_parm)
        self.delete_security_group( group_id=group_id )
        self.poll_security_group( vpc_id, group_id, target_group_exists=False, poll_interval_secs=poll_interval_secs, poll_max_minutes=poll_max_minutes )    
        return True
                    
    
    def create_security_group_sync( self, vpc_id, sg_name, sg_group_name, sg_desc,
                               poll_interval_secs=5, poll_max_minutes=10, inbound_rule_items=None ):
        
        group_id, is_group_exists = self.is_security_group_exists( vpc_id, group_name=sg_group_name )
        if is_group_exists: raise ipcaws.exception.SecurityGroupAlreadyExistsError( sg_group_name, sg_group_name)
        security_group = self.create_security_group( sg_group_name, sg_desc, vpc_id=vpc_id )    
        self.poll_security_group( vpc_id, security_group.id, target_group_exists=True, poll_interval_secs=poll_interval_secs, poll_max_minutes=poll_max_minutes )    
        security_group.add_tag( 'Name', value=sg_name )
        if inbound_rule_items != None: self.authorize_inbound_rules( security_group, inbound_rule_items )
        return security_group
            
    
    def create_unique_security_group_sync( self, vpc_id, sg_name_prefix, inbound_rule_items=None,
                                      max_attempts=100, poll_interval_secs=5, poll_max_minutes=10, ):    
        # Create uniquely named SG
        security_group = None
        start_suffix = int(time.time()*100)
        for unique_suffix in range( start_suffix, (max_attempts+start_suffix) ):
            sg_name_desc = sg_name_prefix + str( unique_suffix )
            group_id, is_group_exists =  self.is_security_group_exists( vpc_id, group_name=sg_name_desc )
            if is_group_exists: continue
            security_group = self.create_security_group( sg_name_desc, sg_name_desc, vpc_id=vpc_id )
            break;
        if security_group == None: raise ipcaws.exception.SecurityGroupAlreadyExistsError( sg_name_desc, sg_name_desc)
        self.poll_security_group( vpc_id, security_group.id, target_group_exists=True, poll_interval_secs=poll_interval_secs, poll_max_minutes=poll_max_minutes )    
        if inbound_rule_items != None: self.authorize_inbound_rules( security_group, inbound_rule_items )
        return security_group
    
    
    def authorize_inbound_rules( self, security_group, inbound_rule_items ):
            for inbound_rule_item in inbound_rule_items:
                security_group.authorize( ip_protocol=inbound_rule_item.ip_protocol, from_port=inbound_rule_item.from_port, 
                                          to_port=inbound_rule_item.to_port, cidr_ip=inbound_rule_item.cidr_ip )   
                

    def is_security_group_exists( self, vpc_id, group_name=None, group_id=None):
        filters = { 'vpc_id': vpc_id,}
        is_group_exists = False
        groups = self.get_all_security_groups( filters=filters )
        for group in groups: 
            if (group_name != None and group_name == group.name) or (group_id != None and group_id == group.id):
                group_id = group.id
                is_group_exists = True
                break;
        return group_id, is_group_exists

  
    def poll_security_group( self, vpc_id, group_id, target_group_exists=True,
                                    poll_interval_secs=5, poll_max_minutes=10 ):
        # Its possible that the delete_security_group returned but the SG isn't deleted yet - poll for it
        filters = { 'vpc_id': vpc_id,}
        expires_at = time.time() + (poll_max_minutes * 60)
        while time.time() <= expires_at:
            is_group_exists = False
            groups = self.get_all_security_groups( filters=filters )
            for group in groups:
                if group_id == group.id:
                    is_group_exists = True
                    break
            if target_group_exists == is_group_exists: return
            time.sleep( poll_interval_secs )
    
        raise ipcaws.exception.SecurityGroupTimeoutError( group_id )


class InboundRuleItem:
    def __init__(self, ip_protocol='tcp', from_port=22, to_port=None, cidr_ip='0.0.0.0/0' ):
        self.ip_protocol = ip_protocol
        self.from_port = from_port
        if to_port != None: self.to_port = to_port
        else: self.to_port = from_port
        self.cidr_ip = cidr_ip
