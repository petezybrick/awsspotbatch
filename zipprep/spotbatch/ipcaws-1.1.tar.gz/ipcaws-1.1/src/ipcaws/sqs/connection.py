'''
Created on Mar 6, 2015

@author: pete.zybrick
'''
import time
import boto.sqs.connection
import ipcaws.exception

class IpcSQSConnection(boto.sqs.connection.SQSConnection):

    def __init__(self, **kw_params):
        super(IpcSQSConnection, self).__init__(**kw_params)


    def delete_queue_sync( self, queue,  poll_interval_secs=2, poll_max_minutes=10, is_quiet=True):
        is_queue_exists = self.is_queue_exists( queue.name )
        if not is_quiet and is_queue_exists: raise ipcaws.exception.QueueDoesntExistError( queue.name, queue.name )
        if is_quiet and not is_queue_exists: return False   # queue doesn't exist, no reason to delete it
        is_deleted = self.delete_queue( queue )
        self.poll_queue_exists( queue.name, target_is_queue_exists=False, poll_interval_secs=poll_interval_secs, poll_max_minutes=poll_max_minutes )    
        return is_deleted


    def create_queue_sync( self, queue_name, visibility_timeout=None,
                      poll_interval_secs=2, poll_max_minutes=10, ):
        if self.is_queue_exists( queue_name ): raise ipcaws.exception.QueueAlreadyExistsError( queue_name, queue_name )
        queue = self.create_queue( queue_name, visibility_timeout=visibility_timeout )
        self.poll_queue_exists( queue_name, target_is_queue_exists=True, poll_interval_secs=poll_interval_secs, poll_max_minutes=poll_max_minutes )    
        return queue
            
    
    def create_unique_queue_sync( self, queue_name_prefix='q_', visibility_timeout=None,
                             max_attempts=100, poll_interval_secs=2, poll_max_minutes=10,        ):
        unique_suffix = int(time.time()*100)
        queue = None
        for i in range(1,(max_attempts+1)):
            queue_name = queue_name_prefix + str( unique_suffix + i )
            if self.is_queue_exists( queue_name ): continue
            queue = self.create_queue( queue_name, visibility_timeout=visibility_timeout )
            break
        if queue == None: raise ipcaws.exception.QueueUniqueAllExistError( queue_name )
        self.poll_queue_exists( queue_name, target_is_queue_exists=True, poll_interval_secs=poll_interval_secs, poll_max_minutes=poll_max_minutes )    
        return queue
    
    
    def poll_queue_exists( self, queue_name, target_is_queue_exists=True, poll_interval_secs=2, poll_max_minutes=10 ):
        expires_at = time.time() + (poll_max_minutes * 60)
        while time.time() <= expires_at:
            is_queue_exists = self.is_queue_exists( queue_name )
            if is_queue_exists == target_is_queue_exists: return
            time.sleep( poll_interval_secs )
        raise ipcaws.exception.QueuePollTimeoutError( queue_name )
                
        
    def is_queue_exists( self, queue_name ):
        is_queue_exists = False
        check_queues = self.get_all_queues()
        for check_queue in check_queues:
            if check_queue.name == queue_name: 
                is_queue_exists = True
                break
        return is_queue_exists
