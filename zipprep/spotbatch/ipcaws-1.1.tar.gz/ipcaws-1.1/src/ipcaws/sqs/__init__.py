import boto.sqs
from boto.regioninfo import get_regions
from boto.sqs.regioninfo import SQSRegionInfo
from ipcaws.iam import findAccessSecretKeysByProfileName


def regions():
    """
    Get all available regions for the SQS service.

    :rtype: list
    :return: A list of :class:`boto.sqs.regioninfo.RegionInfo`
    """
    return get_regions(
        'sqs',
        region_cls=IpcSQSRegionInfo
    )
    
    
def connect_to_region( region_name, **kw_params):
    profile_name = kw_params['profile_name']
    if profile_name != None:
        aws_access_key_id, aws_secret_access_key = findAccessSecretKeysByProfileName( profile_name )
        kw_params['aws_access_key_id'] = aws_access_key_id
        kw_params['aws_secret_access_key'] = aws_secret_access_key
        kw_params.pop('profile_name', None)
    for region in regions():
        if region.name == region_name:
            return region.connect(**kw_params)
    return None


class IpcSQSRegionInfo(SQSRegionInfo):

    def __init__(self, connection=None, name=None, endpoint=None,
                 connection_cls=None):
        from ipcaws.sqs.connection import IpcSQSConnection
        super(IpcSQSRegionInfo, self).__init__(connection, name, endpoint,
                            IpcSQSConnection)
        self.connection_cls = IpcSQSConnection
