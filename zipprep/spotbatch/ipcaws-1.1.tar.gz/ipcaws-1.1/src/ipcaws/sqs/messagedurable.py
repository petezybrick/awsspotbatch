'''
Created on Mar 17, 2015

@author: pete.zybrick
'''
import boto
import time
import ipcaws.sqs

   
import logging
logger = logging.getLogger(__name__)
    
    
class SqsMessageDurable():
    
    def __init__(self, queue_name, region_name, profile_name=None,
                 send_attempt_max = 6, send_attempt_interval_secs = 10,
                 receive_attempt_max = 6, receive_attempt_interval_secs = 10,
                 delete_attempt_max = 6, delete_attempt_interval_secs = 10,
                 ):
        self.queue_name = queue_name
        self.region_name = region_name
        self.profile_name = profile_name
        self.send_attempt_max = send_attempt_max
        self.send_attempt_interval_secs = send_attempt_interval_secs
        self.receive_attempt_max = receive_attempt_max
        self.receive_attempt_interval_secs = receive_attempt_interval_secs
        self.delete_attempt_max = delete_attempt_max
        self.delete_attempt_interval_secs = delete_attempt_interval_secs
        self.sqs_conn = None
        self.queue = None
        self.reconnect()
        
        
    def reconnect(self):
        try:
            self.sqs_conn = None
            self.queue = None
            self.sqs_conn = ipcaws.sqs.connect_to_region( self.region_name, profile_name=self.profile_name )
            if( self.sqs_conn != None ): self.queue = self.sqs_conn.get_queue( self.queue_name )
            else: logger.warn('self.sqs_conn == None')
            if self.queue != None:
                # Long Polling
                # http://docs.aws.amazon.com/AWSSimpleQueueService/latest/SQSDeveloperGuide/sqs-long-polling.html
                is_set_ok = self.sqs_conn.set_queue_attribute( self.queue, 'ReceiveMessageWaitTimeSeconds', '20' )
                if not is_set_ok: logger.warn('Failed: set_queue_attribute ReceiveMessageWaitTimeSeconds')   
            else: logger.warn('self.sqs_conn == None')                
        except boto.exception.EC2ResponseError as e: 
            logger.warn( "Connection/get_queue EC2ResponseError: " + str(e) )
            pass
        except StandardError as e:
            logger.warn( "Connection/get_queue error: " + str(e) )
            pass


    def send_message(self, raw_text ):
        send_attempt_cnt = 0,
        while True:
            try:
                self.sqs_conn.send_message( self.queue, raw_text.encode('base64') )
                return
            except boto.exception.EC2ResponseError as e:
                logger.warn( "send_message EC2ResponseError, attempt=" + str(send_attempt_cnt) + ", error: " + str(e) )
                send_attempt_cnt += 1
                if( send_attempt_cnt > self.send_attempt_max ): raise e
            except StandardError as e:
                logger.warn( "send_message StandardError, attempt=" + str(send_attempt_cnt) + ", error: " + str(e) )
                send_attempt_cnt += 1
                if( send_attempt_cnt > self.send_attempt_max ): raise e
            
            time.sleep( self.send_attempt_interval_secs )            
            self.reconnect()

    def receive_message(self):
        return self.receive_messages( number_messages=1 )


    def receive_messages(self, number_messages=1):
        receive_attempt_cnt = 0,
        while True:
            try:
                messages = self.sqs_conn.receive_message( self.queue, number_messages=number_messages,
                                                 visibility_timeout=None, attributes=None,
                                                 wait_time_seconds=None, message_attributes=None)
                return messages
            except boto.exception.EC2ResponseError as e:
                logger.warn( "receive_messages EC2ResponseError, attempt=" + str(receive_attempt_cnt) + ", error: " + str(e) )
                receive_attempt_cnt += 1
                if( receive_attempt_cnt > self.receive_attempt_max ): raise e
            except StandardError as e:
                logger.warn( "receive_messages StandardError, attempt=" + str(receive_attempt_cnt) + ", error: " + str(e) )
                receive_attempt_cnt += 1
                if( receive_attempt_cnt > self.receive_attempt_max ): raise e
            
            time.sleep( self.receive_attempt_interval_secs )
            self.reconnect()


    def delete_message(self, message):
        return self.delete_messages( [message] )


    def delete_messages(self, messages):
        delete_attempt_cnt = 0,
        while True:
            try:
                while len(messages) > 0:
                    message = messages[0]
                    message.delete()
                    messages.pop(0)
                return
            except boto.exception.EC2ResponseError as e:
                logger.warn( "delete_messages EC2ResponseError, attempt=" + str(delete_attempt_cnt) + ", error: " + str(e) )
                delete_attempt_cnt += 1
                if( delete_attempt_cnt > self.delete_attempt_max ): raise e
            except StandardError as e:
                logger.warn( "delete_messages StandardError, attempt=" + str(delete_attempt_cnt) + ", error: " + str(e) )
                delete_attempt_cnt += 1
                if( delete_attempt_cnt > self.delete_attempt_max ): raise e
            
            time.sleep( self.delete_attempt_interval_secs )
            self.reconnect()

