'''
Created on Mar 6, 2015

@author: pete.zybrick
'''
import time
import boto.iam.connection
import ipcaws.exception

import logging
logger = logging.getLogger(__name__)


class IpcIAMConnection(boto.iam.connection.IAMConnection):

    def __init__(self, aws_access_key_id=None, aws_secret_access_key=None, **kwargs):
        super(IpcIAMConnection, self).__init__(aws_access_key_id=None, aws_secret_access_key=None, **kwargs)


    def create_role_instance_profile_sync( self, policy=None, role_name=None, instance_profile_name=None, policy_name=None, 
                                           max_attempts=100, poll_interval_secs=5, poll_max_minutes=10 ):
        if policy == None: raise ValueError('Policy is required')
        if role_name == None: raise ValueError('Role Name is required')
        if instance_profile_name == None: raise ValueError('Instance Profile Name is required')
        if policy_name == None: raise ValueError('Policy Name is required')

        self.create_instance_profile( instance_profile_name )
        self.poll_instance_profile_exists( instance_profile_name, target_instance_profile_exists=True )
        self.create_role( role_name )
        self.poll_role_exists( role_name, target_role_exists=True )
        self.add_role_to_instance_profile( instance_profile_name, role_name ) 
        self.put_role_policy( role_name, policy_name, policy)
        return RoleInstanceProfileItem( instance_profile_name, role_name, policy_name )


    def create_unique_role_instance_profile_sync( self, policy=None, 
                                      role_name_prefix='role_', instance_profile_name_prefix='ip_',
                                      policy_name_prefix='Policy-', max_attempts=100, 
                                      poll_interval_secs=5, poll_max_minutes=10 ):
        if policy == None: raise ValueError('Policy is required')
        policy_name = None
        instance_profile_name = None
        role_name = None
        
        # Create unique instance profile name and verify it exists
        unique_suffix = int(time.time()*100)
        for i in range(1,(max_attempts+1)):
            instance_profile_name = instance_profile_name_prefix + str( unique_suffix )
            try:
                self.create_instance_profile( instance_profile_name )
                break;
            except boto.exception.BotoServerError as e:
                if e.error_code == 'EntityAlreadyExists' and i<max_attempts: unique_suffix += 1
                else: raise e
        
        # Its possible that the create_instance_profile returned but the IP isn't available yet - poll for it
        self.poll_instance_profile_exists( instance_profile_name, target_instance_profile_exists=True )
    
        # Create unique role name and verify it exists
        unique_suffix = int(time.time()*100)
        for i in range(1,(max_attempts+1)):
            role_name = role_name_prefix + str( unique_suffix )
            try:
                self.create_role( role_name )
                policy_name = policy_name_prefix + str( unique_suffix )
                break;
            except boto.exception.BotoServerError as e:
                if e.error_code == 'EntityAlreadyExists' and i<max_attempts: unique_suffix += 1
                else: raise e
        
        # Its possible that the create_role returned but the role isn't available yet - poll for it
        self.poll_role_exists( role_name, target_role_exists=True )
        self.add_role_to_instance_profile( instance_profile_name, role_name ) 
        self.put_role_policy( role_name, policy_name, policy)
        return RoleInstanceProfileItem( instance_profile_name, role_name, policy_name )
    
    
    def delete_role_instance_profile_sync( self, role_instance_profile_item=None, role_name=None, instance_profile_name=None, policy_name=None, 
                                      max_attempts=100, poll_interval_secs=5, poll_max_minutes=10 ):
        if role_instance_profile_item != None:
            role_name = role_instance_profile_item.role_name
            instance_profile_name = role_instance_profile_item.instance_profile_name
            policy_name = role_instance_profile_item.policy_name
            
        if role_name == None: raise ValueError('Role Name is required')
        if instance_profile_name == None: raise ValueError('Instance Profile Name is required')
        if policy_name == None: raise ValueError('Policy Name is required')

        self.remove_role_from_instance_profile( instance_profile_name, role_name)
        self.delete_role_policy( role_name, policy_name)  
        self.delete_role( role_name )
        self.poll_role_exists( role_name, target_role_exists=False )
        self.delete_instance_profile( instance_profile_name )
        self.poll_instance_profile_exists( instance_profile_name, target_instance_profile_exists=False )


    def poll_role_exists(self, role_name, target_role_exists=True, poll_interval_secs=5, poll_max_minutes=10 ):
        expires_at = time.time() + (poll_max_minutes * 60)
        while time.time() <= expires_at:
            if target_role_exists == self.is_role_exists( role_name ): return
            time.sleep( poll_interval_secs )
        raise ipcaws.exception.RoleTimeoutError( role_name + ', target_role_exists=' + str(target_role_exists) )


    def is_role_exists(self, role_name ):
        marker = None
        while True: 
            list_roles_response = self.list_roles( marker=marker )
            for role in list_roles_response.list_roles_result.roles:
                if role_name == role.role_name: return True
            if list_roles_response.list_roles_result.is_truncated == 'true': marker=list_roles_response.list_roles_result.marker
            else: break
        return False


    def poll_instance_profile_exists(self, instance_profile_name, target_instance_profile_exists=True, poll_interval_secs=5, poll_max_minutes=10 ):
        expires_at = time.time() + (poll_max_minutes * 60)
        while time.time() <= expires_at:
            if target_instance_profile_exists == self.is_instance_profile_exists( instance_profile_name ): return
            time.sleep( poll_interval_secs )
        raise ipcaws.exception.InstanceTimeoutError( instance_profile_name + ', target_instance_profile_exists=' + str(target_instance_profile_exists) )
    

    def is_instance_profile_exists( self, instance_profile_name ):
        marker = None
        while True: 
            list_instance_profiles_response = self.list_instance_profiles( marker=marker )
            for instance_profile in list_instance_profiles_response.list_instance_profiles_result.instance_profiles:
                if instance_profile_name == instance_profile.instance_profile_name: return True
            if list_instance_profiles_response.list_instance_profiles_result.is_truncated == 'true': 
                marker = list_instance_profiles_response.list_instance_profiles_result.marker
            else: break
        return False
    

class RoleInstanceProfileItem:
    '''
    classdocs
    '''

    def __init__(self, instance_profile_name, role_name, policy_name ):
        self.instance_profile_name = instance_profile_name
        self.role_name = role_name
        self.policy_name = policy_name