

def connect_iam(aws_access_key_id=None, aws_secret_access_key=None, **kwargs):
    """
    :type aws_access_key_id: string
    :param aws_access_key_id: Your AWS Access Key ID

    :type aws_secret_access_key: string
    :param aws_secret_access_key: Your AWS Secret Access Key

    :rtype: :class:`ipcaws.iam.connection.IpcIAMConnection`
    :return: A connection to Amazon's IAM
    """
    from ipcaws.iam.connection import IpcIAMConnection
    return IpcIAMConnection(aws_access_key_id, aws_secret_access_key, **kwargs)


def findAccessSecretKeysByProfileName( profile_name ):
    aws_access_key_id = None
    aws_secret_access_key = None
    find_profile_name = '[' + profile_name + ']'
    
    from os.path import expanduser
    aws_keys_file = expanduser("~") + '/.aws/credentials'
    f = open( aws_keys_file, 'r' )
    aws_keys_lines = f.readlines()
    f.close()
    is_found_profile_name = False
    for line in aws_keys_lines:
        line = line.strip()
        if not is_found_profile_name and line == find_profile_name:
            is_found_profile_name = True
        elif is_found_profile_name:
            key, value = line.split("=")
            key = key.strip()
            if key == 'aws_access_key_id': aws_access_key_id = value.strip()
            elif key == 'aws_secret_access_key': aws_secret_access_key = value.strip()
        if aws_access_key_id != None and aws_secret_access_key != None:
            return aws_access_key_id, aws_secret_access_key
                
    return aws_access_key_id, aws_secret_access_key