'''
Created on Mar 3, 2015

@author: pete.zybrick
'''
import boto
import threading
import paramiko

import logging
logger = logging.getLogger(__name__)


class RemoteRunThread(threading.Thread):
    '''
    classdocs
    '''


    def __init__(self, thread_num, ip_address, timeout=60, username='ec2-user', key_filename=None, src_script=None, dst_script=None, cmd_line=None):
        threading.Thread.__init__(self)
        self.thread_num = thread_num
        self.ip_address = ip_address
        self.timeout = timeout
        self.username = username
        self.key_filename = key_filename
        self.src_script = src_script
        self.dst_script = dst_script
        self.cmd_line = cmd_line
        self.std_out_lines = None
        self.std_err_lines = None
        self.remote_exit_status = None


    def run(self):
        try:
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            ssh.connect( self.ip_address, timeout=self.timeout, username=self.username, key_filename=self.key_filename )
            
            sftp_client = ssh.open_sftp()
            sftp_client.put( self.src_script, self.dst_script )
            sftp_client.close()
            
            chan = ssh._transport.open_session()   
            chan.exec_command( self.cmd_line )
            
            # note that out/err doesn't have inter-stream ordering locked down.
            stdout = chan.makefile('rb', -1)
            stderr = chan.makefile_stderr('rb', -1)
            self.std_out_lines = ''.join(stdout.readlines())
            self.std_err_lines = ''.join(stderr.readlines())
            self.remote_exit_status = chan.recv_exit_status()
            ssh.close()
        except boto.exception.EC2ResponseError as e:
            logger.error( e )
            raise e
        