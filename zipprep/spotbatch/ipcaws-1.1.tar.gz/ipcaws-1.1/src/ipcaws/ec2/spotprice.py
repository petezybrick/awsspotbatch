'''
Created on Feb 28, 2015

@author: pete.zybrick
'''
import operator
import boto.ec2
import boto.vpc
import ipcaws.ec2.connection
from ipcaws.vpc.connection import InboundRuleItem

import logging
logger = logging.getLogger(__name__)


def find_spot_cheapest_prices( instance_type='m3.large', product_description='Linux/UNIX', profile_name=None, region_filter=None, verbose=False):
    spot_cheapest_items = []
    
    all_regions = boto.ec2.regions( profile_name=profile_name )
    for region in all_regions:
        if region_filter != None and not region.name in region_filter: continue
        try:
            ec2_conn_region = boto.ec2.connect_to_region( region.name, profile_name=profile_name )
            zones = ec2_conn_region.get_all_zones()
        except boto.exception.EC2ResponseError as e:
            if e.code == 'AuthFailure':
                if verbose: logger.warn( 'Not authorized for region: ' + region.name )
                continue
            else: raise e            
        for zone in zones:
            if verbose: logger.info( 'Checking Zone: ' + zone.name )
            spot_price_histories = ec2_conn_region.get_spot_price_history( instance_type=instance_type, product_description=product_description, max_results=1, availability_zone=zone.name )
            if len(spot_price_histories) > 0:
                spot_cheapest_items.append( SpotCheapestItem( instance_type, product_description, region, zone, spot_price_histories[0].price ) )

    spot_cheapest_items.sort( key=operator.attrgetter('price'))
    return spot_cheapest_items


class SpotCheapestItem():

    def __init__(self, instance_type, product_description, region, zone, price ):           
        self.instance_type = instance_type
        self.product_description = product_description
        self.region = region
        self.zone = zone
        self.price = price
    
    
    def is_valid( self ):
        if self.region != None: return True
        else: return False
        
        
    def to_string( self ):
        region_name = 'None Found'
        zone_name = 'None Found'
        price = 'N/A'
        if self.region != None: 
            region_name = self.region.name
            zone_name = self.zone.name
            price = str(self.price)
        return 'SpotCheapestItem: instance_type=' + self.instance_type + ', product_description=' + self.product_description + ', region.name=' + region_name + ', zone.name=' + zone_name + ', price=' + price


class SpotRegionItem():
    
    def __init__(self, region_name, profile_name=None, kp_name_prefix='kp_spot_', key_path=None, vpc_id=None, sg_name_prefix='sg_spot_' ): 
        if key_path == None: raise ValueError('key_path is required')
        if vpc_id == None: raise ValueError('vpc_id is required')
        
        self.vpc_conn = boto.vpc.connect_to_region( region_name, profile_name=profile_name )
        self.ec2_conn = boto.ec2.connect_to_region( region_name, profile_name=profile_name )
    
        key_pair = ipcaws.ec2.connection.IpcEC2Connection.create_unique_key_pair_sync( kp_name_prefix, key_path )
        self.key_name = key_pair.name
    
        self.security_group = self.vpc_conn.create_unique_security_group( vpc_id, sg_name_prefix, 
                                                            inbound_rule_items= [ InboundRuleItem( from_port=22 )]
                                                            )
        self.security_group_ids = [ self.security_group.id ]

