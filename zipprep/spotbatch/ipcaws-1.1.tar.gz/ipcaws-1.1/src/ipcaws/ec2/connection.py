'''
Created on Mar 6, 2015

@author: pete.zybrick
'''
import os
import time
import boto.ec2.connection
import ipcaws.exception
import ipcaws.ec2

import logging
logger = logging.getLogger(__name__)


class IpcEC2Connection(boto.ec2.connection.EC2Connection):
    # technically the Spot Request is on hold during the until "valid_until" is passed, but in reality
    # the spot request will most likely go into "schedule-expired" state, so don't wait for it, try somewhere else
    SPOT_REQUEST_CONSTRAINTS = ['capacity-not-available','capacity-oversubscribed','price-too-low',
                                'not-scheduled-yet','launch-group-constraint','az-group-constraint',
                                'placement-group-constraint','constraint-not-fulfillable'
                           ]


    def __init__(self, **kw_params):
        super(IpcEC2Connection, self).__init__(**kw_params)


    def delete_key_pair_sync( self, kp_name, key_path, max_attempts=100, poll_interval_secs=5, poll_max_minutes=10 ):
        key = self.delete_key_pair( kp_name )          
        os.remove( key_path + kp_name + '.pem' )
        # Its possible that the create_key_pair returned but the KP isn't available yet - poll for it
        self.poll_key_pair( kp_name, target_kp_exists=False )
        return


    def create_key_pair_sync( self, kp_name, key_path, max_attempts=100, poll_interval_secs=5, poll_max_minutes=10 ):
        key = self.create_key_pair( kp_name )
        key.save( key_path )            
        # Its possible that the create_key_pair returned but the KP isn't available yet - poll for it
        self.poll_key_pair( kp_name, target_kp_exists=True )
    
        return key


    def create_unique_key_pair_sync( self, kp_name_prefix, key_path, 
                                max_attempts=100, poll_interval_secs=5, poll_max_minutes=10 ):
        unique_suffix = int(time.time()*100)
        for i in range(1,(max_attempts+1)):
            kp_name = kp_name_prefix + str( unique_suffix )
            try:
                key = self.create_key_pair( kp_name )
                break;
            except boto.exception.EC2ResponseError as e:
                if e.error_code == 'InvalidKeyPair.Duplicate' and i<max_attempts: unique_suffix += 1
                else: raise e
        key.save( key_path )
            
        # Its possible that the create_key_pair returned but the KP isn't available yet - poll for it
        self.poll_key_pair( kp_name, target_kp_exists=True )
    
        return key
    
    
    def is_key_pair_exists( self, kp_name ):
        check_key_pairs = self.get_all_key_pairs( )
        for check_key_pair in check_key_pairs: 
            if check_key_pair.name == kp_name: return True
        return False 

  
    def poll_key_pair( self, kp_name, target_kp_exists=True,
                       poll_interval_secs=5, poll_max_minutes=10 ):
        expires_at = time.time() + (poll_max_minutes * 60)
        while time.time() <= expires_at:
            is_kp_exists = self.is_key_pair_exists( kp_name )
            if target_kp_exists == is_kp_exists: return
            time.sleep( poll_interval_secs )
        raise ipcaws.exception.KeyPairTimeoutError( kp_name )

    
    def poll_instance_running( self, instance_id, interval_secs, max_minutes, verbose=False ):
        return self.poll_instances( [instance_id], interval_secs, max_minutes, ipcaws.ec2.INSTANCE_STATE_CODE_RUNNING, verbose )
    
    
    def poll_instances_running( self, instance_ids, interval_secs, max_minutes, verbose=False ):
        return self.poll_instances( instance_ids, interval_secs, max_minutes, ipcaws.ec2.INSTANCE_STATE_CODE_RUNNING, verbose )
    
    
    def poll_instance_stopped( self, instance_id, interval_secs, max_minutes, verbose=False ):
        return self.poll_instances( [instance_id], interval_secs, max_minutes, ipcaws.ec2.INSTANCE_STATE_CODE_STOPPED, verbose )
    
    
    def poll_instances_stopped( self, instance_ids, interval_secs, max_minutes, verbose=False ):
        return self.poll_instances( instance_ids, interval_secs, max_minutes, ipcaws.ec2.INSTANCE_STATE_CODE_STOPPED, verbose )
    
    
    def poll_instance_terminated( self, instance_id, interval_secs, max_minutes, verbose=False ):
        return self.poll_instances( [instance_id], interval_secs, max_minutes, ipcaws.ec2.INSTANCE_STATE_CODE_TERMINATED, verbose )
    
    
    def poll_instances_terminated( self, instance_ids, interval_secs, max_minutes, verbose=False ):
        return self.poll_instances( instance_ids, interval_secs, max_minutes, ipcaws.ec2.INSTANCE_STATE_CODE_TERMINATED, verbose )
    
    
    def poll_instance( self, instance_id, interval_secs, max_minutes, target_state_code, verbose=False ):
        return self.poll_instances( [instance_id], interval_secs, max_minutes, target_state_code, verbose )
    
    
    def poll_instances( self, instance_ids, interval_secs, max_minutes, target_state_code, verbose=False ):
        if verbose: logging.info( 'Start Polling ' + str(len(instance_ids )) + ', target_status_code=' + str(target_state_code) )
        if target_state_code == ipcaws.ec2.INSTANCE_STATE_CODE_RUNNING: include_all_instances = False
        else: include_all_instances = True  # by default, STOPPED or TERMINATED aren't includes
        map_poll_instance_ids = {}
        for instance_id in instance_ids: map_poll_instance_ids[instance_id] = None
        expires_at = time.time() + (max_minutes * 60)
        while time.time() <= expires_at:
            instance_statuss = self.get_all_instance_status(instance_ids=map_poll_instance_ids.keys(), include_all_instances=include_all_instances)
            for instance_status in instance_statuss:
                if verbose: logging.info( '   Instance: ' + instance_status.id + ', instance_status.state_code=' + str(instance_status.state_code) + ', instance_status.system_status.status=' + instance_status.system_status.status )
                # For Running, check both the State Code and Status - the instances isn't available until both are up
                if target_state_code == ipcaws.ec2.INSTANCE_STATE_CODE_RUNNING and instance_status.state_code == target_state_code and instance_status.system_status.status == 'ok': 
                    map_poll_instance_ids.pop( instance_status.id, None )
                # Status check isn't used for Stopped or Terminating
                elif (target_state_code == ipcaws.ec2.INSTANCE_STATE_CODE_TERMINATED or target_state_code == ipcaws.ec2.INSTANCE_STATE_CODE_STOPPED) \
                    and instance_status.state_code == target_state_code: map_poll_instance_ids.pop( instance_status.id, None )
                # This can happen with Spot instances - while waiting for checks to complete, the spot request is terminated by price
                elif( target_state_code == ipcaws.ec2.INSTANCE_STATE_CODE_RUNNING and instance_status.state_code == ipcaws.ec2.INSTANCE_STATE_CODE_TERMINATED) : 
                    raise ipcaws.exception.InstancePollTerminatedError( instance_status.id )
            if( len(map_poll_instance_ids) == 0 ): return
            if verbose: logger.info( '   Poll Loop processed, num instances remaining to target_state: ' + str(len(map_poll_instance_ids)) )
            time.sleep( interval_secs )
        
        raise ipcaws.exception.InstancePollTimeoutError( 'Timeout polling ' + str(map_poll_instance_ids.keys()), map_poll_instance_ids.keys(), target_state_code )


    def poll_spot_request( self, ec2_conn, in_spot_instance_requests,  interval_secs, max_minutes, 
                      cancel_and_terminate_after_timeout=True, verbose=False ):
        if verbose: logger.info( 'Start Polling ' + str(len(in_spot_instance_requests)) )
        instance_ids = []
        expires_at = time.time() + (max_minutes * 60)
        
        map_spot_poll_request_ids = {}
        poll_spot_request_ids = []
        for in_spot_instance_request in in_spot_instance_requests: 
            poll_spot_request_ids.append( in_spot_instance_request.id )
            map_spot_poll_request_ids[ in_spot_instance_request.id ] = None
    
        while time.time() <= expires_at:
            # Sometimes the first call will fail with Invalid Spot Request, so just try again
            try:
                poll_spot_instance_requests = ec2_conn.get_all_spot_instance_requests(request_ids=map_spot_poll_request_ids.keys() )
            except boto.exception.EC2ResponseError:
                continue
            
            for poll_spot_instance_request in poll_spot_instance_requests:
                # Constraint encountered, this request probably won't succeed, will probably expire before constraints met
                if poll_spot_instance_request.status.code in self.SPOT_REQUEST_CONSTRAINTS: 
                    raise ipcaws.exception.SpotConstraintError(poll_spot_instance_request.status.code)
                if verbose:
                    verbose_instance_id = 'None'
                    if poll_spot_instance_request.instance_id != None: verbose_instance_id = poll_spot_instance_request.instance_id
                    logger.info( '   SpotRequest: ' + poll_spot_instance_request.id + ', instance_id=' + verbose_instance_id + ', status=' + poll_spot_instance_request.status.code + ' ' + poll_spot_instance_request.status.update_time )
                if poll_spot_instance_request.instance_id != None: 
                    map_spot_poll_request_ids.pop( poll_spot_instance_request.id, None )
                    instance_ids.append(poll_spot_instance_request.instance_id)
            if( len(map_spot_poll_request_ids) == 0 ): return instance_ids
            if verbose: logger.info( '\tPoll Loop processed, num spot requests remaining: ' + str(len(map_spot_poll_request_ids)) )
            time.sleep( interval_secs )
            
        # Timeout - optionally cancel the Request and terminate any started instances
        if cancel_and_terminate_after_timeout:
            if len(map_spot_poll_request_ids.keys()) > 0:
                ec2_conn.cancel_spot_instance_requests( map_spot_poll_request_ids.keys() )
            if len(instance_ids) > 0:   
                ec2_conn.terminate_instances(instance_ids )  
        
        raise ipcaws.exception.SpotPollTimeoutError( 'Timeout polling ' + str(map_spot_poll_request_ids.keys()), str(map_spot_poll_request_ids.keys()) )
