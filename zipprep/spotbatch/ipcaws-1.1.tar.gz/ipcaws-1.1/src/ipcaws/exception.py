'''
Created on Mar 6, 2015

@author: pete.zybrick
'''

class InstancePollTimeoutError(Exception):

    def __init__(self, message, instance_ids, target_status_code ):
        super(InstancePollTimeoutError, self).__init__(message)
        self.instance_ids = instance_ids
        self.target_status_code = target_status_code


class InstancePollTerminatedError(Exception):

    def __init__(self, message, instance_id ):
        super(InstancePollTimeoutError, self).__init__(message)
        self.instance_id = instance_id


class KeyPairTimeoutError(Exception):

    def __init__(self, message, kp_name ):
        super(KeyPairTimeoutError, self).__init__(message)
        self.kp_name = kp_name


class InstanceProfileTimeoutError(Exception):

    def __init__(self, message, instance_profile_name, create_or_delete='create' ):
        super(InstanceProfileTimeoutError, self).__init__(message)
        self.instance_profile_name = instance_profile_name
        self.create_or_delete = create_or_delete
        

class RoleTimeoutError(Exception):

    def __init__(self, message ):
        super(RoleTimeoutError, self).__init__(message)
        

class InstanceTimeoutError(Exception):

    def __init__(self, message ):
        super(InstanceTimeoutError, self).__init__(message)
        

class SpotPollTimeoutError(Exception):

    def __init__(self, message, spot_request_ids ):
        super(SpotPollTimeoutError, self).__init__(message)
        self.spot_request_ids = spot_request_ids
        

class SpotConstraintError(Exception):

    def __init__(self, message ):
        super(SpotConstraintError, self).__init__(message)


class SecurityGroupTimeoutError(Exception):

    def __init__(self, message, security_group_id ):
        super(SecurityGroupTimeoutError, self).__init__(message)
        self.security_group_id = security_group_id


class SecurityGroupDoesntExistError(Exception):

    def __init__(self, message, security_group_id ):
        super(SecurityGroupDoesntExistError, self).__init__(message)
        self.security_group_id = security_group_id


class SecurityGroupAlreadyExistsError(Exception):

    def __init__(self, message, security_group_id ):
        super(SecurityGroupAlreadyExistsError, self).__init__(message)
        self.security_group_id = security_group_id


class QueuePollTimeoutError(Exception):

    def __init__(self, message, queue_name ):
        super(QueuePollTimeoutError, self).__init__(message)
        self.queue_name = queue_name


class QueueUniqueAllExistError(Exception):

    def __init__(self, message ):
        super(QueueUniqueAllExistError, self).__init__(message)


class QueueAlreadyExistsError(Exception):

    def __init__(self, message, queue ):
        super(QueueAlreadyExistsError, self).__init__(message)
        self.queue = queue


class QueueDoesntExistError(Exception):

    def __init__(self, message, queue ):
        super(QueueDoesntExistError, self).__init__(message)
        self.queue = queue
